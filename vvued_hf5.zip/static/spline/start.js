import { Application } from './runtime.js';
const app = new Application();
app.load('./spline/scene.json');