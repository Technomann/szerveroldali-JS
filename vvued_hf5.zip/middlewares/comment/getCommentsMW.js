
/**
 * Get all comments for specific spacecraft or spacecrafts by spacecraftId and puts them into locals and calls next
 */
 const reuireOption = require('../utility/requireOption');

 module.exports = function(objectRepository){
     return function(req, res, next){
         next();
     };
 };