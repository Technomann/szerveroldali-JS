
/**
 * Deletes comment based on id, then redirects to /spacecraft/:spacecraftid/details
 */
 const reuireOption = require('../utility/requireOption');

 module.exports = function(objectRepository){
     return function(req, res, next){
         next();
     };
 };