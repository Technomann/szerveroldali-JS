const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/vvued2');

module.exports = mongoose;
